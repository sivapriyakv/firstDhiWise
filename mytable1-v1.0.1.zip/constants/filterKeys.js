/**
 * filterKeys.js
 */

module.exports = { FILTER_KEYS: { ID: 'id' } };
